/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strndup.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mponomar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/04 19:05:49 by mponomar          #+#    #+#             */
/*   Updated: 2017/10/04 19:05:50 by mponomar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strndup(const char *s1, int size)
{
	char *a;

	a = (char *)malloc(size + 1);
	if (a != NULL)
	{
		*(a + size) = '\0';
		strncpy(a, s1, size);
	}
	return (a);
}
